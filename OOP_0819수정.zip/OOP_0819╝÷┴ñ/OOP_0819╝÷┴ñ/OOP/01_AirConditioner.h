#pragma once
class AirConditioner
{
private:
	bool isActivated;

public:
	bool GetIsActivated() const;
	void SetActivate(bool activate);

};
