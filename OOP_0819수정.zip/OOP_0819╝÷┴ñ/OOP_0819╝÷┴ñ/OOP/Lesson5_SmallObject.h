#pragma once
class Lesson5_SmallObject
{
	char c;
};

