#include "Lesson5_MediumObject.h"
