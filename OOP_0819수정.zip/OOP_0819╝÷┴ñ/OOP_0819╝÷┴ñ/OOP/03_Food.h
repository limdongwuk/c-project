#pragma once
#include <iostream>

class Food
{
public:
	std::string name;
	Food(const std::string& name);


};

