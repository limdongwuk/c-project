#pragma once
class Lesson5_MediumObject
{
private:
	char c[1024];
};

