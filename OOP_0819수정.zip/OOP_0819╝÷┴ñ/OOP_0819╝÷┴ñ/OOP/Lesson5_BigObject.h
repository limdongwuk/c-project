#pragma once
class Lesson5_BigObject
{
private:
public:
	int c[1024][1024];
	Lesson5_BigObject();
};

