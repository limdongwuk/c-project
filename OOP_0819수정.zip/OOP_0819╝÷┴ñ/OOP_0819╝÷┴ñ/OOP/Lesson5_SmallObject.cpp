#include "Lesson5_SmallObject.h"
