#pragma once
#include "03_Food.h"

class Bowl
{
public:
	Food& food;
	Bowl(Food& food);
};

